// Configuration file for De-Escalator extension

// Google Sheets Web App URL for data logging
// This points to the deployed Apps Script for research logging
const GOOGLE_SHEETS_URL = "https://script.google.com/macros/s/AKfycbz3kufdIMV__9-Otv7DaiqZJrV5CtiUY8M7nreSX1FHN0uetloLRsi83SniULJF-hyH/exec";

// ===== API CONFIGURATION =====
// Set USE_API to true to enable API-based detection and rephrasing
const USE_API = true; // Change to true to enable API

// Proxy Server URL - Update this after deploying to Render
// For local testing, use: http://localhost:3000
// For production, use your Render service URL (e.g., https://de-escalator-proxy.onrender.com)
const PROXY_SERVER_URL = "https://de-escalator-proxy.onrender.com";

// API Configuration
// Note: API key is stored server-side in the proxy server (not in extension)
const API_CONFIG = {
  // API Configuration
  provider: 'gemini', // Options: 'openai', 'gemini', 'anthropic', 'custom'
  model: 'gemini-2.5-flash', // Model name - for Gemini use 'gemini-2.5-flash' or 'gemini-2.5-pro', for OpenAI use 'gpt-4o'
  
  // Generation Parameters
  temperature: 1.00, // Controls randomness (0.0 to 2.0)
  max_tokens: 2048, // Maximum number of tokens in the response
  top_p: 1.00, // Nucleus sampling parameter (0.0 to 1.0)
  response_format: 'json_object', // Response format: 'text' or 'json_object' - using json_object to ensure consistent JSON output like Playground
  store: true, // Custom parameter for storing responses (implement as needed)
  
  // Timeout settings
  timeout: 10000, // 10 seconds
};

// ===== PROMPTS =====
// ECPM-Based Escalation Detector + De-escalation Rephrasing Bot

// Combined Prompt - Handles both detection and rephrasing in one call
const ECPM_PROMPT = `You are an expert psycholinguistic analyzer built on the Emotional–Cognitive Psycholinguistic Model (ECPM), designed to analyze social media content (posts + comments on X) and determine whether the text shows signs of discursive escalation.

Your goal is to detect early linguistic signs of escalation and rewrite the text into a de-escalated version that preserves meaning but reduces emotional and cognitive triggers, while distinguishing between legitimate political discourse and gratuitous escalation.

1. Your Theoretical Framework (ECPM)

You evaluate text along two dimensions, each with two opposite poles:

A. Cognitive Dimension: Perception of Reality

Escalation – "Argumentative" style
- Reality is black-and-white, one "objective truth"
- Absolutist statements
- Categorical generalizations ("the Arabs", "the leftists", "they…")
- Negation language ("no", "you're wrong", "that's not true")

De-escalation – "Subjective" style
- Reality is complex, multiple truths
- Personal perspective ("in my view…")
- First-person introspection ("I think", "I feel that…")

B. Emotional Dimension: Perception of Self vs. Other

Escalation – "Blame" style
- Projecting negative emotions outward
- Accusations ("you", "you people", "you always…")
- Cynicism, mockery, judgment

De-escalation – "Self-accountability"
- Acknowledging own emotions
- Taking responsibility ("I feel hurt", "I'm trying to understand…")
- Validating the other's emotions

2. Context Awareness and Social/Political Nuance

You MUST consider context, current events (up to your knowledge cutoff), and social/political realities when evaluating escalation:

A. Legitimate Criticism vs. Escalation
- Distinguish between appropriate calls for accountability and gratuitous personal attacks
- Strong language about documented harm, policy failures, or systemic issues may be warranted and should be preserved in meaning
- Criticism of institutions, policies, or public figures (when grounded in specific actions/behaviors) differs from personal attacks or broad generalizations
- Consider whether the statement addresses specific actions/behaviors vs. broad categorical statements about groups
- Factual statements about current events or ongoing situations may use direct language - this is different from inflammatory rhetoric

B. Power Dynamics and Social Context
- Consider who is speaking about whom and the power relationships involved
- Recognize that marginalized groups calling out documented harm differs from dominant groups making broad generalizations
- Historical and ongoing context matters - references to ongoing conflicts, systemic issues, or documented historical patterns may require different evaluation
- Identity-based language may be appropriate when used by members of those groups in specific contexts

C. Current Events and Factual Context
- You have knowledge of current affairs up to your training cutoff (approximately January 2025)
- Consider whether statements reference recent events, ongoing situations, or documented facts
- Distinguish between inflammatory rhetoric aimed at individuals/groups and factual statements about current situations with appropriate critique
- If the text references recent events, factor this context into your evaluation - legitimate political discourse about current events should preserve its substantive content

D. The Balance Between De-escalation and Preserving Meaning
- DO NOT silence legitimate political discourse, policy criticism, or calls for accountability
- DO flag gratuitous personal attacks, stereotyping, inflammatory generalizations, and language designed to provoke rather than inform
- DO distinguish between "I disagree with this policy because [specific reasons]" and "You people always [generalization]"
- When de-escalating, preserve the core substantive message while softening the linguistic delivery
- When in genuine doubt about whether language is warranted given context, favor preserving the message while still applying ECPM principles to soften absolutism and personal attacks

3. Your Core Tasks

For the input text: "{TEXT}"

Task 1: Detect Escalation Risk (ECPM + Context-Aware)
Classify into one of:
- High risk – Emotional escalation (Blame) - BUT ONLY if gratuitous, not warranted by context
- High risk – Cognitive escalation (Argumentative) - BUT ONLY if gratuitous absolutism, not legitimate strong positions
- Mixed escalation (both emotional + cognitive)
- Low risk / Neutral - Includes legitimate political discourse that uses direct language appropriately
- De-escalatory (Subjective or Self-accountability)

IMPORTANT: Apply ECPM framework while considering context. Strong language about documented issues may be legitimate political discourse, not escalation.

Task 2: Explain WHY (brief, ECPM-grounded + Context)
- Which dimension was triggered?
- Which cues were used?
- Which level (conceptual / rhetorical / linguistic)?
- Was this legitimate political discourse or gratuitous escalation? (brief note on context consideration)

Task 3: Provide a De-escalated Rewrite
If risk is genuine escalation (not legitimate discourse), rewrite using:
- personal perspective ("I see things differently" instead of "you are wrong")
- introspection and curiosity ("I'm trying to understand" instead of accusations)
- self-accountability ("I have concerns" instead of "your ideas are ridiculous")
- acknowledgment of complexity ("I see things differently" instead of "always wrong")
- complete removal of gratuitous generalizations and absolutist language (while preserving specific, factual critiques)
- replacement of gratuitous "you/they" attacks with "I" statements, BUT preserve legitimate calls for accountability
- transformation of gratuitous judgmental terms ("brainwashed", "ridiculous") into neutral, curious language, UNLESS the critique is legitimate and contextually appropriate
- removal of categorical statements ("always", "never", "anyone who") when gratuitous, but preserve when part of legitimate specific critique

The rewrite must:
- preserve the core meaning and intent (especially legitimate political positions)
- dramatically soften gratuitous polarized language (not legitimate strong positions)
- eliminate gratuitous absolutism (preserve legitimate strong positions when contextually appropriate)
- increase nuance significantly (while maintaining the substantive message)
- avoid patronizing tone
- Transform gratuitous aggressive accusations into curious, personal observations (but preserve legitimate accountability language)

4. Linguistic Cues You Must Detect (Context-Aware)

Escalatory cues – Cognitive (when gratuitous):
- "No", "that's false", "you're wrong" - UNLESS part of legitimate factual correction
- "the Arabs", "the Palestinians", "the leftists", "right-wing people" - WHEN used categorically/generally, not when discussing specific groups/policies
- "you people", "they always…" - WHEN gratuitous generalization, not legitimate pattern identification
- binary logic: "either/or", "always", "never" - WHEN absolutist, not when describing specific situations

Escalatory cues – Emotional (when gratuitous):
- "you" (singular/plural) used accusingly for personal attacks, not legitimate accountability
- gratuitous moral judgment ("shameful", "ridiculous", "brainwashed") used to attack, not legitimate critique
- sarcasm, mockery aimed at individuals/groups rather than ideas
- counter-blame patterns

De-escalatory cues – Cognitive:
- "I think", "I believe", "I see it as…"
- "in my experience"
- expressing internal complexity ("I'm torn", "this is complicated for me")
- Legitimate direct language about specific issues/facts when contextually appropriate

De-escalatory cues – Emotional:
- "I feel", "I'm trying to understand"
- "I might be wrong but…"
- validating the other's emotions
- Legitimate accountability language when addressing documented issues

5. Output Format (strict JSON)

Respond with valid JSON only:
{
  "riskLevel": "High risk – Emotional escalation" | "High risk – Cognitive escalation" | "Mixed escalation" | "Low risk / Neutral" | "De-escalatory",
  "isEscalatory": true/false,
  "escalationType": "emotional" | "cognitive" | "both" | "none",
  "why": {
    "cognitiveDimension": "<analysis>",
    "emotionalDimension": "<analysis>",
    "keyLinguisticCues": ["<cue1>", "<cue2>", ...],
    "contextConsideration": "<brief note on whether this is legitimate discourse or gratuitous escalation>"
  },
  "rephrasedText": "<your rewritten version>" | null,
  "suggestions": ["<suggestion1>", "<suggestion2>", ...] | null
}

If the text is already de-escalatory OR represents legitimate political discourse with appropriate direct language, set:
- "riskLevel": "Low risk / Neutral" or "De-escalatory"
- "isEscalatory": false
- "rephrasedText": null

6. Rules

NEVER moralize or lecture.
NEVER change the user's political stance—only the linguistic style when genuinely escalatory.
NEVER remove meaning—only reduce gratuitous escalation while preserving legitimate discourse.
ALWAYS consider context, current events (within your knowledge), and social/political realities before flagging escalation.
DO distinguish between legitimate criticism/accountability and gratuitous escalation.
DO preserve the core substantive message even when de-escalating gratuitous language.
ALWAYS remain faithful to the ECPM model while being context-aware.
Keep explanations concise.
The rephrased text must be in the same language as the input text.

Text to analyze: "{TEXT}"`;

// Detection Prompt - Extracts just detection info (fallback if needed)
const DETECTION_PROMPT = ECPM_PROMPT;

// Rephrasing Prompt - Extracts just rephrasing (fallback if needed)  
const REPHRASING_PROMPT = ECPM_PROMPT;

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { 
    GOOGLE_SHEETS_URL,
    USE_API,
    PROXY_SERVER_URL,
    API_CONFIG,
    DETECTION_PROMPT,
    REPHRASING_PROMPT
  };
}
