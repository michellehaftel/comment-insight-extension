// Configuration file for Discourse Lab extension

// Google Sheets Web App URL for data logging
// This points to the deployed Apps Script for research logging
const GOOGLE_SHEETS_URL = "https://script.google.com/macros/s/AKfycbz3kufdIMV__9-Otv7DaiqZJrV5CtiUY8M7nreSX1FHN0uetloLRsi83SniULJF-hyH/exec";

// ===== API CONFIGURATION =====
// Set USE_API to true to enable API-based detection and rephrasing
const USE_API = true; // Change to true to enable API

// Proxy Server URL - Update this after deploying to Render
// For local testing, use: http://localhost:3000
// For production, use your Render service URL (e.g., https://de-escalator-proxy.onrender.com)
const PROXY_SERVER_URL = "https://de-escalator-proxy.onrender.com";

// API Configuration
// Note: API key is stored server-side in the proxy server (not in extension)
const API_CONFIG = {
  // API Configuration
  provider: 'gemini', // Options: 'openai', 'gemini', 'anthropic', 'custom'
  model: 'gemini-2.5-flash', // Model name - for Gemini use 'gemini-2.5-flash' or 'gemini-2.5-pro', for OpenAI use 'gpt-4o'
  
  // Generation Parameters
  temperature: 1.00, // Controls randomness (0.0 to 2.0)
  max_tokens: 4096, // Maximum number of tokens in the response (increased to handle detailed JSON responses)
  top_p: 1.00, // Nucleus sampling parameter (0.0 to 1.0)
  response_format: 'json_object', // Response format: 'text' or 'json_object' - using json_object to ensure consistent JSON output like Playground
  store: true, // Custom parameter for storing responses (implement as needed)
  
  // Timeout settings
  timeout: 10000, // 10 seconds
};

// ===== PROMPTS =====
// ECPM-Based Escalation Detector + De-escalation Rephrasing Bot
//
// NOTE: This prompt is now OPTIONAL and used only as a fallback.
// The proxy server prioritizes: 1) ECPM_PROMPT environment variable (on Render), 2) This prompt (from extension), 3) Default
// To update the prompt without Chrome Web Store approval:
//   1. Go to Render dashboard → Your service → Environment
//   2. Add/update: ECPM_PROMPT = (paste your prompt here)
//   3. Save and redeploy (or just restart the service)
//
// Combined Prompt - Handles both detection and rephrasing in one call
// This is a FALLBACK - proxy server will use ECPM_PROMPT environment variable if set
const ECPM_PROMPT = `CRITICAL: Respond with ONLY valid JSON. No markdown, no explanations. Start with { and end with }.

You are an ECPM (Emotional-Cognitive Psycholinguistic Model) analyzer for social media. Detect escalation and rephrase using de-escalation principles while preserving essence.

ECPM FRAMEWORK:
- Cognitive: Argumentative (absolute truths, "you're wrong") vs Subjective ("I see things differently")
- Emotional: Blame ("you're making me sick") vs Self-accountability ("I feel frustrated")

CONTEXT AWARENESS (CRITICAL):
When context is provided, analyze:
1. What relationships/figures are mentioned (e.g., Netanyahu-Trump relationship)
2. Whether the text is legitimate political discourse or gratuitous escalation
3. How context affects the analysis (e.g., criticizing documented actions vs personal attacks)
Distinguish legitimate criticism from gratuitous attacks based on context.

CONTEXT: {CONTEXT}
TEXT: "{TEXT}"

TASK: Detect escalation and rephrase if needed, preserving ESSENCE (core message) while transforming DELIVERY (linguistic style).

REPHRASING PRINCIPLES:

1. ESSENCE PRESERVATION (CRITICAL):
Before transforming, identify:
- What is the substantive claim/position? (PRESERVE THIS)
- What is the underlying feeling/concern? (PRESERVE THIS)
- What specific facts/policies/relationships are referenced? (PRESERVE THIS)

2. TRANSFORMATION:
- Cognitive: Absolute → Personal ("You're wrong" → "I see things differently")
- Emotional: Blame → Self-accountability ("You're making me sick" → "I'm feeling very upset")
- Profanity → Neutral expressions ("fucking terrible" → "very concerning")
- Maintain second-person address naturally when original uses "you"
- Use context to reference specific issues/facts that create disagreement

3. CRITICAL: Rephrased text must feel like the SAME PERSON expressing the SAME IDEA, just using ECPM-aligned language.

GOOD Examples (preserving essence):
- "You're wrong about everything" → "I see many things differently from you" (preserves: disagreement)
- "You're making me sick" → "I'm feeling very upset by this" (preserves: strong negative emotion)
- "You lefties have no idea" → "I see things differently from some on the left. I'm trying to understand their perspective." (preserves: disagreement with group)
- "This policy is fucking terrible" → "I strongly disagree with this policy. Can you help me understand your reasoning?" (preserves: policy disagreement, removes profanity)
- "Bibi and Trump's relationship is just political theater" → "I see their relationship as more transactional than genuine. I'm trying to understand the dynamics here." (preserves: critique of relationship, removes dismissiveness)
- "This policy harmed thousands" → DO NOT rephrase (legitimate discourse)

BAD Examples (losing essence - AVOID):
- "You're wrong about this policy - it's hurting people" → "I see things differently" ❌ PROBLEM: Lost the substantive claim about policy harm
- "This terrible policy caused documented harm" → "I have some concerns" ❌ PROBLEM: Too weak for legitimate factual criticism

OUTPUT (JSON only):
{
  "riskLevel": "High risk – Emotional escalation" | "High risk – Cognitive escalation" | "Mixed escalation" | "Low risk / Neutral" | "De-escalatory",
  "isEscalatory": true/false,
  "escalationType": "emotional" | "cognitive" | "both" | "none",
  "why": {
    "cognitiveDimension": "<brief analysis>",
    "emotionalDimension": "<brief analysis>",
    "keyLinguisticCues": ["<cue1>", "<cue2>"],
    "contextUnderstanding": {
      "detectedContext": "<what context was identified - original post topic, figures mentioned, relationships, etc., or 'No context provided'>",
      "identifiedRelationships": "<relationships or dynamics identified (e.g., 'Netanyahu-Trump relationship', 'political leader-follower dynamic') or 'None identified'>",
      "contextualRelevance": "<how context affects escalation analysis - did it help distinguish legitimate discourse from gratuitous escalation?>",
      "contextSufficiency": "<whether context was sufficient to understand the bigger picture or insufficient>"
    }
  },
  "rephrasedText": "<rephrased version>" | null,
  "suggestions": null
}

If already de-escalatory or legitimate discourse: isEscalatory=false, rephrasedText=null.

JSON ONLY.`;

// Detection Prompt - Extracts just detection info (fallback if needed)
const DETECTION_PROMPT = ECPM_PROMPT;

// Rephrasing Prompt - Extracts just rephrasing (fallback if needed)  
const REPHRASING_PROMPT = ECPM_PROMPT;

// Escalation Prompt (Devil Bot) - Makes ALREADY escalatory content EVEN MORE escalatory
// NOTE: This prompt is OPTIONAL and used only as a fallback.
// The proxy server prioritizes: 1) ECPM_ESCALATION_PROMPT environment variable (on Render), 2) This prompt (from extension), 3) Default
// This is a FALLBACK - proxy server will use ECPM_ESCALATION_PROMPT environment variable if set
// Devil bot uses the SAME escalation detection as Angel - only triggers when escalation is detected.
// Angel offers de-escalation; Devil offers an even MORE escalated version.
const ECPM_ESCALATION_PROMPT = `CRITICAL: Respond with ONLY valid JSON. No markdown, no explanations. Start with { and end with }.

You are an ECPM (Emotional-Cognitive Psycholinguistic Model) analyzer for social media. The input text has ALREADY been detected as escalatory. Your task is to provide an EVEN MORE escalated version while keeping the user's tone of voice (in a higher volume). Combine emotional and cognitive escalation if needed.

ECPM FRAMEWORK (ESCALATION AMPLIFICATION):
- Cognitive: Amplify absolute truths, make arguments more categorical ("You're wrong" → "You're completely and utterly wrong")
- Emotional: Amplify blame and projection ("You're making me sick" → "You make me physically ill")
- Combine both dimensions when appropriate for maximum impact

CONTEXT AWARENESS (CRITICAL):
When context is provided, use it to make the escalation more targeted and impactful (e.g., naming specific figures, relationships, or policies mentioned in context).

CONTEXT: {CONTEXT}
TEXT: "{TEXT}"

TASK: The input text is ALREADY escalatory. You MUST provide an EVEN MORE escalated version.
- Preserve the user's tone of voice but amplify it (same person, higher volume)
- If the text is primarily cognitive → add emotional charge, or vice versa
- Combine emotional and cognitive escalation if it strengthens the message
- NEVER return null. ALWAYS provide a more escalated rephrasing.

ESCALATION AMPLIFICATION PRINCIPLES:

1. ESSENCE PRESERVATION (CRITICAL):
- What is the substantive claim/position? (PRESERVE AND STRENGTHEN)
- What is the underlying feeling? (AMPLIFY)
- What specific facts/policies are referenced? (PRESERVE AND MAKE MORE DIRECT)

2. TRANSFORMATION (MAKE EVEN MORE IMPACTFUL):
- Strong → Stronger ("You're wrong" → "You're completely delusional")
- Blame → More direct blame ("You're annoying" → "You're insufferable")
- Categorical → More absolute ("That's stupid" → "That's idiotic and everyone knows it")
- Add conviction, directness, and intensity
- Use stronger language - elevate to the next level

3. CRITICAL: Output must feel like the SAME PERSON expressing the SAME IDEA, just louder and more direct.

GOOD Examples (amplifying already-escalatory text):
- "You're wrong about everything" → "You're completely delusional and wrong about everything"
- "You're making me sick" → "You make me physically ill with your nonsense"
- "You lefties have no idea" → "You lefties are clueless and have no idea what you're talking about"
- "This policy is terrible" → "This policy is fucking disgraceful and harms real people"
- "Their relationship is just political theater" → "Their relationship is a disgusting charade of political theater"
- "That's a stupid argument" → "That's the most ridiculous, idiotic argument I've ever heard"

OUTPUT (JSON only):
{
  "riskLevel": "High risk – Emotional escalation" | "High risk – Cognitive escalation" | "Mixed escalation",
  "isEscalatory": true,
  "escalationType": "emotional" | "cognitive" | "both" | "none",
  "why": {
    "cognitiveDimension": "<brief analysis>",
    "emotionalDimension": "<brief analysis>",
    "keyLinguisticCues": ["<cue1>", "<cue2>"]
  },
  "rephrasedText": "<even more escalated version>",
  "suggestions": null
}

CRITICAL RULES - READ CAREFULLY:
1. rephrasedText MUST ALWAYS be a string - the EVEN MORE escalated version (never null)
2. rephrasedText MUST be the actual escalated text the user would post, NOT meta-commentary
3. The input is ALREADY escalatory - your job is to make it MORE so
4. Keep the user's tone of voice, just amplify it
5. Combine emotional and cognitive escalation when it makes the message stronger

JSON ONLY.`;

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { 
    GOOGLE_SHEETS_URL,
    USE_API,
    PROXY_SERVER_URL,
    API_CONFIG,
    DETECTION_PROMPT,
    REPHRASING_PROMPT
  };
}
