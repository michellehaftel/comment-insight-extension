// Configuration file for De-Escalator extension
// Currently no configuration is needed - all processing happens locally!
// This file is kept for future configuration options.

