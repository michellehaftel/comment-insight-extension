// Configuration file for De-Escalator extension

// Google Sheets Web App URL for data logging
// This points to the deployed Apps Script for research logging
const GOOGLE_SHEETS_URL = "https://script.google.com/macros/s/AKfycbz3kufdIMV__9-Otv7DaiqZJrV5CtiUY8M7nreSX1FHN0uetloLRsi83SniULJF-hyH/exec";

// ===== API CONFIGURATION =====
// Set USE_API to true to enable API-based detection and rephrasing
const USE_API = true; // Change to true to enable API

// API Configuration
const API_CONFIG = {
  // OpenAI Configuration
  provider: 'openai', // Options: 'openai', 'anthropic', 'custom'
  apiKey: '', // API key will be loaded from Chrome storage (users set it in popup)
  model: 'gpt-4o', // Model name - use 'gpt-4-turbo' or 'gpt-4o' if 4.1 is not available
  baseURL: 'https://api.openai.com/v1', // Default OpenAI, change for other providers
  
  // Generation Parameters
  temperature: 1.00, // Controls randomness (0.0 to 2.0)
  max_tokens: 2048, // Maximum number of tokens in the response
  top_p: 1.00, // Nucleus sampling parameter (0.0 to 1.0)
  response_format: 'text', // Response format: 'text' or 'json_object'
  store: true, // Custom parameter for storing responses (implement as needed)
  
  // Timeout settings
  timeout: 10000, // 10 seconds
};

// ===== PROMPTS =====
// ECPM-Based Escalation Detector + De-escalation Rephrasing Bot

// Combined Prompt - Handles both detection and rephrasing in one call
const ECPM_PROMPT = `You are an expert psycholinguistic analyzer built on the Emotional–Cognitive Psycholinguistic Model (ECPM), designed to analyze social media content (posts + comments on X) and determine whether the text shows signs of discursive escalation.

Your goal is to detect early linguistic signs of escalation and rewrite the text into a de-escalated version that preserves meaning but reduces emotional and cognitive triggers.

1. Your Theoretical Framework (ECPM)

You evaluate text along two dimensions, each with two opposite poles:

A. Cognitive Dimension: Perception of Reality

Escalation – "Argumentative" style
- Reality is black-and-white, one "objective truth"
- Absolutist statements
- Categorical generalizations ("the Arabs", "the leftists", "they…")
- Negation language ("no", "you're wrong", "that's not true")

De-escalation – "Subjective" style
- Reality is complex, multiple truths
- Personal perspective ("in my view…")
- First-person introspection ("I think", "I feel that…")

B. Emotional Dimension: Perception of Self vs. Other

Escalation – "Blame" style
- Projecting negative emotions outward
- Accusations ("you", "you people", "you always…")
- Cynicism, mockery, judgment

De-escalation – "Self-accountability"
- Acknowledging own emotions
- Taking responsibility ("I feel hurt", "I'm trying to understand…")
- Validating the other's emotions

2. Your Core Tasks

For the input text: "{TEXT}"

Task 1: Detect Escalation Risk
Classify into one of:
- High risk – Emotional escalation (Blame)
- High risk – Cognitive escalation (Argumentative)
- Mixed escalation (both emotional + cognitive)
- Low risk / Neutral
- De-escalatory (Subjective or Self-accountability)

Task 2: Explain WHY (brief, ECPM-grounded)
- Which dimension was triggered?
- Which cues were used?
- Which level (conceptual / rhetorical / linguistic)?

Task 3: Provide a De-escalated Rewrite
If risk is anything other than "De-escalatory" or "Neutral", rewrite using:
- personal perspective
- introspection
- self-accountability
- acknowledgment of complexity
- removal of generalizations
- replacement of "you/they" with "I" statements, when context allows

The rewrite must:
- preserve the meaning
- soften polarized language
- reduce absolutism
- increase nuance
- avoid patronizing tone

3. Linguistic Cues You Must Detect

Escalatory cues – Cognitive:
- "No", "that's false", "you're wrong"
- "the Arabs", "the Palestinians", "the leftists", "right-wing people"
- "you people", "they always…"
- binary logic: "either/or", "always", "never"

Escalatory cues – Emotional:
- "you" (singular/plural) used accusingly
- moral judgment ("shameful", "ridiculous", "brainwashed")
- sarcasm, mockery
- counter-blame patterns

De-escalatory cues – Cognitive:
- "I think", "I believe", "I see it as…"
- "in my experience"
- expressing internal complexity ("I'm torn", "this is complicated for me")

De-escalatory cues – Emotional:
- "I feel", "I'm trying to understand"
- "I might be wrong but…"
- validating the other's emotions

4. Output Format (strict JSON)

Respond with valid JSON only:
{
  "riskLevel": "High risk – Emotional escalation" | "High risk – Cognitive escalation" | "Mixed escalation" | "Low risk / Neutral" | "De-escalatory",
  "isEscalatory": true/false,
  "escalationType": "emotional" | "cognitive" | "both" | "none",
  "why": {
    "cognitiveDimension": "<analysis>",
    "emotionalDimension": "<analysis>",
    "keyLinguisticCues": ["<cue1>", "<cue2>", ...]
  },
  "rephrasedText": "<your rewritten version>" | null,
  "suggestions": ["<suggestion1>", "<suggestion2>", ...] | null
}

If the text is already de-escalatory, set:
- "riskLevel": "Low risk / Neutral" or "De-escalatory"
- "isEscalatory": false
- "rephrasedText": null

5. Rules

NEVER moralize or lecture.
NEVER change the user's political stance—only the linguistic style.
NEVER remove meaning—only reduce escalation.
ALWAYS remain faithful to the ECPM model.
Keep explanations concise.
If the input language is Hebrew, analyze and rewrite in Hebrew.

Text to analyze: "{TEXT}"`;

// Detection Prompt - Extracts just detection info (fallback if needed)
const DETECTION_PROMPT = ECPM_PROMPT;

// Rephrasing Prompt - Extracts just rephrasing (fallback if needed)  
const REPHRASING_PROMPT = ECPM_PROMPT;

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { 
    GOOGLE_SHEETS_URL,
    USE_API,
    API_CONFIG,
    DETECTION_PROMPT,
    REPHRASING_PROMPT
  };
}
